import pygame as p
import ChessEngine

p.init()
WIDHT = HEIGHT = 512 #400 is another option
DIMENSION = 8 #dimensions of a chess board are 8x8
SQ_SIZE = HEIGHT // DIMENSION
MAX_FPS = 15 #for animations later on
IMAGES = {}

'''''
Initialize a global dictionary of images.
'''''

def loadImages():
 pieces = ['wp', 'wR', 'wN', 'wB', 'wK', 'wQ', 'bp', 'bR', 'bN', 'bB', 'bK', 'bQ']
 for piece in pieces:
    IMAGES[piece] = p.transform.scale(p.image.load("img/" + piece + ".png"), (SQ_SIZE, SQ_SIZE))
#note: we can acess an image by saying 'IMAGES['wp']'

#note: the main driver
def main():
   p.init()
   screen = p.display.set_mode((WIDHT, HEIGHT))
   clock = p.time.Clock()
   screen.fill(p.Color("white"))
   gs = ChessEngine.GameState()
loadImages() #only once
running = True
while running:
  for e in p.event.get():
    if e.type == p.QUIT:
      running = False
   drawGameState(screen, gs)
   clock.tick(MAX_FPS)
  p.display.flip()

def drawGameState(screen, gs):
  drawBoard(screen)
  drawPieces(screen, gs.board)
  
#draw the squares on the board
def drawBoard(screen):
  colors = [p.Color("white"), p.Color("gray")]
  for r in range (DIMENSION):S
      for c in range (DIMENSION):
         color = colors[((r+c) % 2)]
         p.draw.rect(screen,color, p.rect(c*SQ_SIZE, r*SQ_SIZE, SQ_SIZE, SQ_SIZE))
    
#draw the pieces on the board using current GameState.board    
def drawPieces(screen, board):
  

if __name__ == "__main__":
    main()