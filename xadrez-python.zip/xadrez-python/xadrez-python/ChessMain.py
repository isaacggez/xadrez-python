import pygame as p

p.init()
WIDHT = HEIGHT = 512 #400 is another option
DIMENSION = 8 #dimensions of a chess board are 8x8
SQ_SIZE = HEIGHT // DIMENSION
MAX_FPS = 15 #for animations later on
IMAGES = {}

'''''
Initialize a global dictionary of images.
'''''

def loadImages():
 pieces = ['wp', 'wR', 'wN', 'wB', 'wK', 'wQ', 'bp', 'bR', 'bN', 'bB', 'bK', 'bQ']
 for piece in pieces:
    IMAGES[piece] = p.transform.scale(p.image.load("img/" + piece + ".png"), (SQ_SIZE, SQ_SIZE))
#note: we can acess an image by saying 'IMAGES['wp']'

#note: the main driver
def main():
   p.init()
   screen = p.display.set_mode((WIDHT, HEIGHT))
   clock = p.time.Clock()
   screen.fill(p.Color("white"))
   gs = ChessEngine.GameState()
loadImages()
running = True

main()